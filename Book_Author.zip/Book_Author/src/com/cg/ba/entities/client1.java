package com.cg.ba.entities;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

public class client1 {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
	    EntityManager em=emf.createEntityManager();
	    em.getTransaction().begin();

	    
	    String qrystr="from Book";
	    TypedQuery<Book> qry=em.createQuery(qrystr,Book.class);
	    List<Book> list = qry.getResultList();
	    for(Book book : list){
	    	System.out.println(book.getBookId()+""+book.getTitle()+""+book.getPrice());
	    }
	    
	    em.getTransaction().commit();
	   // System.out.println("Successfully added");
	    em.close();
	    emf.close();
	}

}
