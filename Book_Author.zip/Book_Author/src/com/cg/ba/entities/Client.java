package com.cg.ba.entities;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Client {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
	    EntityManager em=emf.createEntityManager();
	    em.getTransaction().begin();
	    
	    Book b1 = new Book();
	    b1.setTitle("Harry Potter");
	    b1.setPrice(1500);
	    
	    Book b2 = new Book();
	    b2.setTitle("Twilight");
	    b2.setPrice(2000);
	    
	    Book b3 = new Book();
	    b3.setTitle("New Moon");
	    b3.setPrice(1000);
	    
	    
	    Author a1 = new Author();
	    a1.setName("JK Rowling");
	    
	    a1.addBook(b1);
	    a1.addBook(b2);
	    a1.addBook(b3);
	    
	    Author a2 = new Author();
	    a2.setName("Stephen Mayer");
	    
	    a2.addBook(b1);
	    a2.addBook(b2);
	    
	    em.persist(a1);
		em.persist(a2);
	    
	    
	    em.getTransaction().commit();
	    System.out.println("Successfully added");
	    em.close();
	    emf.close();
	}

}
