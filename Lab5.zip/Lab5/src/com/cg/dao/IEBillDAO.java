package com.cg.dao;

import com.cg.dto.BillDTO;
import com.cg.exception.BillUserException;

public interface IEBillDAO {
public boolean insert(BillDTO billDTO)throws BillUserException;

public String getConsName(int consumerNo)throws BillUserException;

}
